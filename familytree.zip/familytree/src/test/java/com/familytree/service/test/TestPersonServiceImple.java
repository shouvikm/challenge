package com.familytree.service.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.familytree.dao.impl.PersonDaoImpl;
import com.familytree.datasource.impl.InternalDataPopulator;
import com.familytree.domain.Person;
import com.familytree.service.impl.PersonServiceImpl;

public class TestPersonServiceImple {

	@Test
	public void testGetPerson() {
		PersonDaoImpl i = new PersonDaoImpl();
		InternalDataPopulator p = new InternalDataPopulator();
		p.loadData();
		i.setDataSource(p);
		PersonServiceImpl imp = new PersonServiceImpl();
		imp.setDao(i);
		Person person = imp.getPerson("Person-1");
		assertEquals("Person-1", person.getName());
		assertEquals(3, person.getChildren().size());
		
	}

}
