package com.familytree.domain.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.familytree.domain.Person;

public class TestPerson {

	@Test
	public void testPerson() {
		Person person = new Person("name", 30);
		person.setFather(new Person("father", 60));
		person.setMother(new Person("mother",50));
		person.setSpouse(null);
		assertEquals("father", person.getFather().getName());
		assertEquals("mother", person.getMother().getName());
		
	}

}
