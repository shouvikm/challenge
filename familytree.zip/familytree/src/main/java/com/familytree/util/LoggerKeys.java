package com.familytree.util;

/**
 * Lpgger keys
 * 
 */
public class LoggerKeys {
	public static final String METHOD_ENTER="METHOD_ENTER";
	public static final String METHOD_EXIT="METHOD_EXIT";
	public static final String DATA_RETRIEVED="DATA_RETRIEVED";
}
