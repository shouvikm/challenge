package com.familytree.util;

public class StringConstants {
	public static final String NOT_FOUND = "NotFound";
	public static final String FATHER = "Father";
	public static final String MOTHER = "Mother";
	public static final String NONE = "None";
	public static final String NAME = "Name:-";
	public static final String AGE = "Age:-";
}
