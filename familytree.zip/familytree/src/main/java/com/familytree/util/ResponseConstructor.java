package com.familytree.util;

import java.io.Writer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.ui.Model;

import com.familytree.domain.FamilyProjectSuper;
import com.familytree.domain.Person;
import com.familytree.service.IPersonService;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import com.thoughtworks.xstream.io.json.JettisonMappedXmlDriver;
import com.thoughtworks.xstream.io.json.JsonWriter;

/**
 * 
 * This class is responsible for constructing a json response and give it back
 * to the calling clients. This in turn uses the service interfaces to fetch the
 * records.
 *
 */
public class ResponseConstructor extends FamilyProjectSuper {
	static Class clazz = ResponseConstructor.class;
	static Logger logger = Logger.getLogger(clazz);

	static XStream xstream;
	static {
		xstream = new XStream(new JettisonMappedXmlDriver() {
			public HierarchicalStreamWriter createWriter(Writer writer) {
				return new JsonWriter(writer, JsonWriter.STRICT_MODE);
			}
		});
		xstream.alias("person", Person.class);
	}

	private IPersonService iPService;

	/**
	 * 
	 * @param name
	 * @return
	 */
	public String getPerson(String name) {
		logger.trace(LoggerKeys.METHOD_ENTER + "getPerson");
		Person person = getiPService().getPerson(name);
		if (person != null) {
			logger.info("Person Retrieved:-" + person.getName());
			logger.trace(LoggerKeys.METHOD_EXIT + "getPerson");
			return xstream.toXML(person);
		} else {
			logger.trace(LoggerKeys.METHOD_EXIT + "getPerson");
			return StringConstants.NOT_FOUND;
		}
	}

	public Model getPersonObj(String name, Model model) {
		logger.trace(LoggerKeys.METHOD_ENTER + "getPerson");
		Person person = getiPService().getPerson(name);
		if (person != null) {
			logger.info("Person Retrieved:-" + person.getName());
			logger.trace(LoggerKeys.METHOD_EXIT + "getPerson");
			model.addAttribute("name", name);
			model.addAttribute("age", person.getAge());
			if(person.getMother() != null){
				model.addAttribute("mother", StringConstants.NAME + person.getMother().getName() + " " + StringConstants.AGE + person.getAge());
			}else{
				model.addAttribute("mother", StringConstants.NONE);
			}
			if(person.getFather() !=null){
				model.addAttribute("father", StringConstants.NAME + person.getFather().getName() + " " + StringConstants.AGE + person.getAge());
			}else{
				model.addAttribute("father", StringConstants.NONE);
			}
			if (person.getSpouse() != null) {
				model.addAttribute("spouse", StringConstants.NAME + person.getSpouse().getName() + " " + StringConstants.AGE + person.getAge());
			} else {
				model.addAttribute("spouse", StringConstants.NONE);
			}
			if (person.getSiblings().size() > 0) {
				List<String> sibNames = new ArrayList<String>();
				Iterator<Person> iter = person.getSiblings().iterator();
				while(iter.hasNext()){
					Person p1 = iter.next();
					sibNames.add(StringConstants.NAME + p1.getName() + StringConstants.AGE + p1.getAge());
				}
				model.addAttribute("siblings", sibNames);
			} else {
				model.addAttribute("siblings", new ArrayList<String>());
			}
			if (person.getChildren().size() > 0) {
				List<String> chNames = new ArrayList<String>();
				Iterator<Person> iter = person.getChildren().iterator();
				while(iter.hasNext()){
					Person p1 = iter.next();
					chNames.add(StringConstants.NAME + p1.getName() + StringConstants.AGE + p1.getAge());
				}
				model.addAttribute("children", chNames);
			} else {
				model.addAttribute("children", new ArrayList<String>());
			}
			return model;
		} else {
			logger.trace(LoggerKeys.METHOD_EXIT + "getPerson");
			return null;
		}
	}

	/**
	 * A pretty printer to print a formatted string.
	 * 
	 * @param person
	 * @return
	 */
	private String prettyPrinter(Person person) {
		String print = "<html><head></head><body><h1>Hello</h1></body></html>";
		return print;
	}

	public IPersonService getiPService() {
		return iPService;
	}

	public void setiPService(IPersonService iPService) {
		this.iPService = iPService;
	}
}
