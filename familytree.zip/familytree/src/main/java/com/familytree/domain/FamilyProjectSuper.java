package com.familytree.domain;

import java.util.Locale;
import java.util.ResourceBundle;

public abstract class FamilyProjectSuper {
	public static ResourceBundle bundle = ResourceBundle.getBundle(
			"com.familytree.resources.LogMessages",
			Locale.getDefault());
}
