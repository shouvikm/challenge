package com.familytree.domain;

import java.util.ArrayList;
import java.util.List;

/**
 * Person domain object.
 *
 */
public class Person {
	private String name;
	private Integer age;
	private Person mother;
	private Person father;
	private Person spouse;
	List<Person> children;
	List<Person> siblings;
	
	public Person(String name, Integer age){
		this.name = name;
		this.age = age;
		this.children = new ArrayList<Person>();
		this.siblings = new ArrayList<Person>();
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the age
	 */
	public Integer getAge() {
		return age;
	}

	/**
	 * @param age the age to set
	 */
	public void setAge(Integer age) {
		this.age = age;
	}

	/**
	 * @return the mother
	 */
	public Person getMother() {
		return mother;
	}

	/**
	 * @param mother the mother to set
	 */
	public void setMother(Person mother) {
		this.mother = mother;
	}

	/**
	 * @return the father
	 */
	public Person getFather() {
		return father;
	}

	/**
	 * @param father the father to set
	 */
	public void setFather(Person father) {
		this.father = father;
	}

	/**
	 * @return the spouse
	 */
	public Person getSpouse() {
		return spouse;
	}

	/**
	 * @param spouse the spouse to set
	 */
	public void setSpouse(Person spouse) {
		this.spouse = spouse;
	}

	/**
	 * @return the children
	 */
	public List<Person> getChildren() {
		return children;
	}

	/**
	 * @return the siblings
	 */
	public List<Person> getSiblings() {
		return siblings;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj==null) return false;
		if(!(obj instanceof Person)) return false;
		Person o = (Person)obj;
		return this.name == o.name;
	}
	
	@Override
	public int hashCode() {
		return age*name.hashCode();
	}

		
}
