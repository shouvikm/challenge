package com.familytree.domain;

import java.util.HashMap;
import java.util.Map;

public class FamilyData {

	public Map<String, Person> familyData;
	
	public FamilyData(){
		this.familyData = new HashMap<String, Person>();
	}

}
