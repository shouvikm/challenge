package com.familytree.datasource.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.familytree.datasource.IDataSource;
import com.familytree.domain.FamilyData;
import com.familytree.domain.FamilyProjectSuper;
import com.familytree.domain.Person;

public class InternalDataPopulator extends FamilyProjectSuper implements IDataSource {
	
	static Class clazz = InternalDataPopulator.class;
	static Logger logger = Logger.getLogger(clazz);

	public HashMap<String, Person> map;

	public InternalDataPopulator() {
		map = new HashMap<String, Person>();
	}

	public FamilyData loadData() {
		logger.info("loading data started");
		FamilyData obj = new FamilyData();

		// root
		Person someForefather = new Person("Person-1", 70);
		Person someForefatherWife = new Person("Person-2", 60);
		someForefather.setSpouse(someForefatherWife);
		someForefatherWife.setSpouse(someForefather);

		// Next Gen

		// Child 1 and Wife
		Person person1 = new Person("Person-3", 40);
		Person person1Wife = new Person("Person-4", 35);
		person1.setSpouse(person1Wife);
		person1Wife.setSpouse(person1);

		// Childs 1's child
		Person c1 = new Person("Person-8", 10);

		// Person's 1's sibbling
		Person s1 = new Person("Person-9", 30);

		// Child 2 and Wife
		Person person2 = new Person("Person-5", 35);
		Person person2Wife = new Person("Person-6", 33);
		person2.setSpouse(person2Wife);
		person2Wife.setSpouse(person2);

		// Child 3
		Person person3 = new Person("Person-7", 32);

		loadChildren(someForefather, someForefatherWife, new Person[] { person1, person2, person3 }, this.map);
		loadChildren(person1, person1Wife, new Person[] { c1 }, this.map);
		loadSibling(person1,new Person[] { s1 }, this.map);
		return obj;
	}

	public void loadChildren(Person father, Person mother, Person[] children, Map<String, Person> map) {
		for (Person p : children) {
			Person f = map.get(father.getName());
			Person m = map.get(mother.getName());
			if (f != null && m != null) {
				Person t = map.get(father.getName());
				Person t1 = map.get(mother.getName());
				if (!(t.getChildren().contains(p))) {
					father.getChildren().add(p);
					mother.getChildren().add(p);
					p.setFather(father);
					p.setMother(mother);
					map.put(p.getName(), p);
					if(p.getSpouse()!=null){
						map.put(p.getSpouse().getName(), p.getSpouse());
					}
				}
			} else {
				father.getChildren().add(p);
				mother.getChildren().add(p);
				p.setFather(father);
				p.setMother(mother);
				map.put(father.getName(), father);
				map.put(mother.getName(), mother);
				map.put(p.getName(), p);
				if(p.getSpouse()!=null){
					map.put(p.getSpouse().getName(), p.getSpouse());
				}
			}
		}
	}

	public void loadSibling(Person person, Person[] siblings, Map<String, Person> map) {
		for (Person p : siblings) {
			Person f = map.get(person.getName());
			if (f != null) {
				Person t = map.get(f.getName());
				if (!(t.getSiblings().contains(p))) {
					person.getSiblings().add(p);
					map.put(p.getName(), p);
				}
			} 
		}
	}

	@Override
	public FamilyData getData() {
		FamilyData data = new FamilyData();
		data.familyData = this.map;
		return data;
	}

}
