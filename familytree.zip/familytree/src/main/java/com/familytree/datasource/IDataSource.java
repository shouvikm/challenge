package com.familytree.datasource;

import com.familytree.domain.FamilyData;

public interface IDataSource {
	public FamilyData getData();
}
