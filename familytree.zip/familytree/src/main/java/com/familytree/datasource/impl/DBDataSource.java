package com.familytree.datasource.impl;

import com.familytree.datasource.IDataSource;
import com.familytree.domain.FamilyData;

/**
 * 
 * This class can be used to get data from Data Base
 *
 */
public class DBDataSource implements IDataSource{

	@Override
	public FamilyData getData() {
		// TODO Not implemented yet
		return null;
	}

}
