package com.familytree.service;

public interface ITreeService {

}
