package com.familytree.service;

import com.familytree.domain.Person;

/**
 * 
 * Person service interface to retrieve or add person to the tree;
 *
 */
public interface IPersonService {
	/**
	 * Get person.
	 * @param name
	 * @return
	 */
	public Person getPerson(String name);
	
	/**
	 * Add the person to the tree.
	 * @param person
	 * @return
	 */
	public Person addPerson(Person person);
}
