package com.familytree.service.impl;

import org.apache.log4j.Logger;

import com.familytree.dao.IPersonDao;
import com.familytree.domain.FamilyProjectSuper;
import com.familytree.domain.Person;
import com.familytree.service.IPersonService;
import com.familytree.util.LoggerKeys;

public class PersonServiceImpl extends FamilyProjectSuper implements IPersonService{
	
	static Class clazz = PersonServiceImpl.class;
	static Logger logger = Logger.getLogger(clazz);
	
	IPersonDao dao;

	@Override
	public Person getPerson(String name) {
		logger.trace(bundle.getString(LoggerKeys.METHOD_ENTER) + "-" + "getPerson");
		return getDao().getPerson(name);
	}

	@Override
	public Person addPerson(Person person) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return the dao
	 */
	public IPersonDao getDao() {
		return dao;
	}

	/**
	 * @param dao the dao to set
	 */
	public void setDao(IPersonDao dao) {
		this.dao = dao;
	}

}
