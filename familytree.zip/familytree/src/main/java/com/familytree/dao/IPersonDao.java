package com.familytree.dao;

import com.familytree.domain.Person;

public interface IPersonDao {
	public Person save(Person person);
	public Person getPerson(String name);
}
