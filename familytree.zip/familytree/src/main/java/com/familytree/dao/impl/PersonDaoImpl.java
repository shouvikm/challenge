package com.familytree.dao.impl;

import java.util.Map;

import org.apache.log4j.Logger;

import com.familytree.dao.IPersonDao;
import com.familytree.datasource.IDataSource;
import com.familytree.domain.FamilyProjectSuper;
import com.familytree.domain.Person;
import com.familytree.util.LoggerKeys;

public class PersonDaoImpl extends FamilyProjectSuper implements IPersonDao {

		static Class clazz = PersonDaoImpl.class;
		static Logger logger = Logger.getLogger(clazz);
		
	private IDataSource dataSource;

	@Override
	public Person save(Person person) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Person getPerson(String name) {
		logger.trace(bundle.getString(LoggerKeys.METHOD_ENTER) + "-" + "getPerson");
		Map<String,Person> map = getDataSource().getData().familyData;
		logger.info(bundle.getString(LoggerKeys.DATA_RETRIEVED ));
		Person person = map.get(name);
		logger.trace(bundle.getString(LoggerKeys.METHOD_EXIT) + "-" + "getPerson");
		return person;
	}

	/**
	 * @return the dataSource
	 */
	public IDataSource getDataSource() {
		return dataSource;
	}

	/**
	 * @param dataSource
	 *            the dataSource to set
	 */
	public void setDataSource(IDataSource dataSource) {
		this.dataSource = dataSource;
	}

}
