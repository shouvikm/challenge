package com.familytree.rest.web;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.familytree.domain.FamilyProjectSuper;
import com.familytree.domain.Person;
import com.familytree.util.ResponseConstructor;
import com.familytree.util.StringConstants;

@Controller
@EnableAutoConfiguration
@ImportResource("beans.xml")
public class WebController {
	static Class clazz = WebController.class;
	static Logger logger = Logger.getLogger(clazz);

	private ResponseConstructor respContrct;

	@RequestMapping("/getPerson")
    String getPerson(@RequestParam(value="name") String name, @RequestParam(value="pretty") String pretty, Model model, RedirectAttributes ra,HttpServletRequest req) {
		if(!Boolean.parseBoolean(pretty)){
			req.setAttribute("name", name);
			return "forward:/getPersonJson";
		}else{
			model = getRespContrct().getPersonObj(name,model);
			if(model != null){
			return "person";
			}else{
				return StringConstants.NOT_FOUND;
			}
		}

	// return getRespContrct().getPerson(name,pretty);
	}
	
	@RequestMapping("/getPersonJson")
	@ResponseBody
	String getPersonJson(HttpServletRequest request){
		String name = request.getParameter("name");
		return getRespContrct().getPerson(name);
	}

	@ExceptionHandler(Throwable.class)
	public String handleError(HttpServletRequest req, Exception exception) {
		logger.error("Request: " + req.getRequestURL() + " raised " + exception);
		return "error";
	}

	/**
	 * @return the respContrct
	 */
	public ResponseConstructor getRespContrct() {
		return respContrct;
	}

	/**
	 * @param respContrct
	 *            the respContrct to set
	 */
	public void setRespContrct(ResponseConstructor respContrct) {
		this.respContrct = respContrct;
	}
}
