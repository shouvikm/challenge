package com.familytree.rest.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaunchingApp {

	public static void main(String[] args) {
		SpringApplication.run(WebController.class, args);
	}

}
